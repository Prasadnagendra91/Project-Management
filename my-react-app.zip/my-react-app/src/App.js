function App() {
  const [tasks, setTasks] = React.useState([]);
  const [filter, setFilter] = React.useState({ key: "priority", value: "" });
  const [newTask, setNewTask] = React.useState({
    task: "",
    stakeholder: "",
    priority: "",
    status: "",
    deadline: "",
    client: "",
    division: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTask((prev) => ({ ...prev, [name]: value }));
  };

  const addTask = () => {
    setTasks((prev) => [...prev, newTask]);
    setNewTask({
      task: "",
      stakeholder: "",
      priority: "",
      status: "",
      deadline: "",
      client: "",
      division: "",
    });
  };

  const filteredTasks = tasks.filter((task) =>
    filter.value ? task[filter.key] === filter.value : true
  );

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Task Management App</h1>
      <div className="mb-4">
        <h2 className="text-xl font-semibold">Add New Task</h2>
        <div className="grid grid-cols-2 gap-4">
          {Object.keys(newTask).map((key) => (
            <div key={key}>
              <label className="block font-medium">{key}</label>
              <input
                type="text"
                name={key}
                value={newTask[key]}
                onChange={handleInputChange}
                className="border p-2 w-full"
              />
            </div>
          ))}
        </div>
        <button
          onClick={addTask}
          className="mt-4 bg-blue-500 text-white px-4 py-2 rounded"
        >
          Add Task
        </button>
      </div>

      <div className="mb-4">
        <h2 className="text-xl font-semibold">Filter Tasks</h2>
        <div className="flex gap-4">
          <select
            onChange={(e) =>
              setFilter((prev) => ({ ...prev, key: e.target.value }))
            }
            className="border p-2"
          >
            {Object.keys(newTask).map((key) => (
              <option key={key} value={key}>
                {key}
              </option>
            ))}
          </select>
          <input
            type="text"
            placeholder="Filter value"
            onChange={(e) =>
              setFilter((prev) => ({ ...prev, value: e.target.value }))
            }
            className="border p-2"
          />
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold">Task List</h2>
        <table className="table-auto w-full border-collapse border border-gray-300">
          <thead>
            <tr>
              {Object.keys(newTask).map((key) => (
                <th key={key} className="border border-gray-300 p-2">
                  {key}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredTasks.map((task, index) => (
              <tr key={index}>
                {Object.values(task).map((value, i) => (
                  <td key={i} className="border border-gray-300 p-2">
                    {value}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}